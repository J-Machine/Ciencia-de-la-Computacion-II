/*
    Los cuatro dígitos adyacentes en el número de 1000 dígitos que tienen el mayor producto son 9 × 9 × 8 × 9 = 5832.
    Find the thirteen adjacent digits in the 1000-digit number that have the greatest product. What is the value of this product?
*/
#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    
    return 0;
}