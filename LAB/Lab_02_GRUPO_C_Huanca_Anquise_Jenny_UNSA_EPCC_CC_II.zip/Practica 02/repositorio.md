Link de repositorio: 

<https://github.com/J-Machine/Ciencia-de-la-Computacion-II/tree/main/LAB/Practica%2002>