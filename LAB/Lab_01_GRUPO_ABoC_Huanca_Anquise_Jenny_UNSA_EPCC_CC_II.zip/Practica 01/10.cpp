/*
    
*/
#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    
    return 0;
}