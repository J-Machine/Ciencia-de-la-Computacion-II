/*
    Un número palindrómico se lee igual en ambos sentidos. 
    El palíndromo más grande hecho del producto de dos números de 2 dígitos es 9009 = 91 × 99.
    Encuentra el palíndromo más grande hecho a partir del producto de dos números de 3 dígitos
*/
#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    for(long int i = 100; i < 1000; i++)
    {
        for(long int j = 100; j < 1000; j++)
        {
            long int prod = i*j;
        }
    }
    return 0;
}